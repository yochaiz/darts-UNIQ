from .BaseNet import BaseNet
from .TinyNet import TinyNet as tinynet
from .ResNet import ResNet as resnet
from .ThinResNet import ThinResNet as thin_resnet
